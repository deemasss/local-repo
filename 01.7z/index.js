const name = prompt('Enter your name');

alert('Hello, ' + name + '! How are you?');