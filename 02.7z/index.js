const a = prompt('Enter first number');
const b = prompt ('Enter second number');
const c = parseInt(a) + parseInt(b);
alert(c);
